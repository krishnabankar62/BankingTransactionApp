//generate otp (one time password) using java...
import java.util.Random;

class OTPgeneration
{
	public static void main(String args[])
	{
		Random rand = new Random();
		System.out.println((int)(rand.nextDouble()*9000+1000));//rand.Double(no arg returns: 0 >= x < 1)
		System.out.println("One Time Password : "+(int)(Math.random()*9000+1000));//Math.random(no arg returns: 0 >= x < 1)
	}
}