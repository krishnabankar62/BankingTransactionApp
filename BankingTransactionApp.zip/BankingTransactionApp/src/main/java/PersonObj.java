import java.util.Map;
import java.util.Scanner;

public class PersonObj
{
	String name;
        int password;
	int ac_no;
	String type;
	float deposit;
	
	PersonObj(String name,int password,int ac_no,String type,float deposit)
	{
		this.name = name;
                this.password = password;
		this.ac_no = ac_no;
		this.type = type;
		this.deposit = deposit;
	}
	
	PersonObj()
	{
		
	}
	
	public static void main(String args[])
	{
		PersonObj obj = new PersonObj("krishna",12345,12345,"saving",5000.25f);
		System.out.println("name : "+obj.name+"\nac_no : "+obj.ac_no+"\ntype : "+obj.type+"\ndeposit : "+obj.deposit);
	}
        
        
        public static void updatePassword(Map<String,PersonObj> map, Scanner sc)
        {
		boolean flag = false;
		System.out.print("\nEnter User name : "); String name = sc.next();
		for(Map.Entry e : map.entrySet())
		{
			if(name.equals(e.getKey()))
			{
				flag = true;
				
				System.out.print("Enter old password : "); Integer password = sc.nextInt();
				if(password.equals(((PersonObj)(e.getValue())).password))
				{
					System.out.print("Enter new password : "); int new_password = sc.nextInt();
					((PersonObj)(e.getValue())).password = new_password;
					
					System.out.println("\nnew_password successfuly updated !");
				}
				else System.out.println("\npassword not matched !");
				
				break;
			}
		}
		if(flag == false)
			System.out.println("\nUser Does not exist !");
	}
        
	
	
	public static void creditAmonut(Map<String,PersonObj> map, Scanner sc)
	{
		boolean flag = false;
		System.out.print("\nEnter User name : "); String name = sc.next();
		for(Map.Entry e : map.entrySet())
		{
			if(name.equals(e.getKey()))
			{
				flag = true;
				
				System.out.print("Enter password : "); Integer password = sc.nextInt();
				if(password.equals(((PersonObj)(e.getValue())).password))
				{
					System.out.print("Enter amount to be withdrawn : "); float deposit = sc.nextFloat();
					if(deposit <= ((PersonObj)(e.getValue())).deposit)
						((PersonObj)(e.getValue())).deposit = ((PersonObj)(e.getValue())).deposit - deposit;
					else
					{
						System.out.println("\nInsufficient balance !");
						break;
					}
					
					System.out.println("\nyour total a/c balance is : "+((PersonObj)(e.getValue())).deposit);
				}
				else System.out.println("\npassword not matched !");
				
				break;
			}
		}
		if(flag == false)
			System.out.println("\nUser Does not exist !");
	}
        
        
	
	public static void debitAmount(Map<String,PersonObj> map, Scanner sc)
	{
		boolean flag = false;
		System.out.print("\nEnter User name : "); String name = sc.next();
		for(Map.Entry e : map.entrySet())
		{
			if(name.equals(e.getKey()))
			{
				flag = true;
				
				System.out.print("Enter password : "); Integer password = sc.nextInt();
				if(password.equals(((PersonObj)(e.getValue())).password))
				{
					System.out.print("Enter amount to be deposited : "); float deposit = sc.nextFloat();
					((PersonObj)(e.getValue())).deposit = ((PersonObj)(e.getValue())).deposit + deposit;
					
					System.out.println("\nyour total a/c balance is : "+((PersonObj)(e.getValue())).deposit);
				}
				else System.out.println("\npassword not matched !");
				
				break;
			}
		}
		if(flag == false)
			System.out.println("\nUser Does not exist !");
	}
        
        
	
	public static void desplayRecord(Map<String,PersonObj> map, Scanner sc)
	{
		boolean flag = false;
		System.out.print("\nEnter User name : "); String name = sc.next();
		for(Map.Entry e : map.entrySet())
		{
			if(name.equals(e.getKey()))
			{
				flag = true;
				
				System.out.print("Enter Password : "); Integer password = sc.nextInt();
				//int ac_no2 = ((PersonObj)(e.getValue())).ac_no;
				if(password.equals(((PersonObj)(e.getValue())).password))
				{
					System.out.println("\nyour name : "+((PersonObj)(e.getValue())).name);
					System.out.println("your ac_no : "+((PersonObj)(e.getValue())).ac_no);
					System.out.println("your a/c type : "+((PersonObj)(e.getValue())).type);
					System.out.println("your total a/c balance is : "+((PersonObj)(e.getValue())).deposit);
				}
				else System.out.println("\npassword not matched !");
				
				break;
			}
		}
		if(flag == false)
			System.out.println("\nUser Does not exist !");
	}
	
	public static PersonObj newRecord(Scanner sc)
	{
		System.out.print("\nEnter your name : "); String name = sc.next();
                System.out.print("Enter your a/c no : "); int ac_no = sc.nextInt();
		System.out.print("Enter type of a/c : "); String type = sc.next();
		System.out.print("Enter deposit amount : "); float deposit = sc.nextFloat();
		
                System.out.print("Enter your mail id : "); String mail = sc.next();
                int password = Mailer.send("krishnabankar62@gmail.com","7566727426",mail,"krishna","One Time Password : ",(int)(Math.random()*9000+1000));
		PersonObj obj = new PersonObj(name,password,ac_no,type,deposit);
		
		return obj;
	}
}