import java.util.Scanner;
import java.util.Map;
import java.util.LinkedHashMap;

public class Transaction
{
	public static void main(String args[])
	{
		System.out.println("Welcome to My Bank !");
		Scanner sc = new Scanner(System.in);
		Map<String,PersonObj> map = new LinkedHashMap<String,PersonObj>();
		PersonObj pobj = new PersonObj();
			
		while(true)
		{
			System.out.println("\nEnter 1 to create new a/c !");
			System.out.println("Enter 2 to mini statement !");
			System.out.println("Enter 3 to deposit money in a/c !");
			System.out.println("Enter 4 to withdraw money from a/c !");
			System.out.println("Enter 5 to change password !");
                        System.out.println("Enter 6 to stop transaction !");
			System.out.print("Enter your choice : ");int choice = sc.nextInt();
		
			switch(choice)
			{
				case 1 : PersonObj obj =  pobj.newRecord(sc);
						 map.put(obj.name,obj);
						 System.out.println("\nyour a/c successfuly created !");
						 break;
							
				case 2 : pobj.desplayRecord(map,sc); break;
				case 3 : pobj.debitAmount(map,sc); break;
				case 4 : pobj.creditAmonut(map,sc); break;
                                case 5 : pobj.updatePassword(map,sc); break;
				case 6 : System.out.println("\nThankyou for visitting here !");
						 return;
				default : System.out.println("Iinvalid Entry !");
			}
		}
	}
}